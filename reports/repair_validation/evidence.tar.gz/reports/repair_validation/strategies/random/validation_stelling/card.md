# Signal Learner card: validation_stelling

**SIMULATED recommendation from a copy learned only from the detector feed. Not city timing; no live control.**

**Decision: no change.** No change: copy quality screening failed: occupancy_mean_abs_diff=30.004 fails screening limit 10; shared_turn_max_share=1.000 fails screening limit 0.2.

No copy forecast: confirmation simulations were not run.

Phases list the legs they serve: N:LT is traffic from the north leg turning left or going through.

| Signal | Cycle s | Offset s | Max greens s (old -> new) | Reason |
|---|---|---|---|---|
| North signal | 80 -> 80 | 0 -> 0 | N:LRT S:LRT: 20 -> 20; N:L S:L: 10 -> 10; E:LT S:R: 10 -> 10; N:R W:LRT: 10 -> 10 | no material change |
| South signal | 80 -> 80 | 64 -> 64 | N:LRT S:LRT: 21 -> 21; N:L S:L: 10 -> 10; E:LRT W:LRT: 10 -> 10; E:L W:LR: 10 -> 10 | no material change |

Phase order, clearances and minimum greens are unchanged. Changes are bounded max greens, cycle and offsets. An engineer approves or rejects; the check rule goes back to old timing if the feed shows traffic clearly worse.
